export const FORMS_API_HOST = process.env.FORMS_API_HOST;
export const SENTRY_DSN = process.env.SENTRY_DSN;
export const ENVIRONMENT = process.env.ENVIRONMENT;
