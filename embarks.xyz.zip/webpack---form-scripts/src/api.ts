import { getContext, getOmnisendContext } from './context';
import { Form, SubmitBackInStockPayload, SubscribeFormData, SubscribePayload, SubscribeResult } from './types';
import { CONTACT_ID_COOKIE } from './constants';

export const subscribeForm = async (form: Form, formData: SubscribeFormData): Promise<SubscribeResult> => {
    const { brand, navigation, forms, cookies } = getContext();
    const { contactID, unconfirmedContactID } = form.getContactIdentifier();

    const payload: SubscribePayload = {
        brandID: brand.getBrandID(),
        formID: form.data.id,
        stepID: form.getCurrentStepID(),
        pageData: {
            URL: navigation.getPageUrl(),
            title: navigation.getPageTitle()
        },
        formData,
        contactID,
        cookieContactID: cookies.get(CONTACT_ID_COOKIE),
        unconfirmedContactID
    };

    const response = await (
        await fetch(forms.getFormsSubscribeEndpoint(), {
            method: 'POST',
            body: JSON.stringify(payload)
        })
    ).json();

    if (response.error) {
        throw response;
    }

    return response;
};

export const submitBackInStock = async (form: Form, formData: SubscribeFormData): Promise<SubscribeResult> => {
    const { brand, navigation, forms, cookies } = getContext();
    const { contactID, unconfirmedContactID } = form.getContactIdentifier();
    const productInfo = getOmnisendContext().getProductInfo();

    const payload: SubmitBackInStockPayload = {
        productID: productInfo?.productID,
        variantID: productInfo?.variantID,
        brandID: brand.getBrandID(),
        formID: form.data.id,
        stepID: form.getCurrentStepID(),
        pageData: {
            URL: navigation.getPageUrl(),
            title: navigation.getPageTitle()
        },
        formData,
        contactID,
        cookieContactID: cookies.get(CONTACT_ID_COOKIE),
        unconfirmedContactID
    };

    const response = await (
        await fetch(forms.getFormsBackInStockEndpoint(), {
            method: 'POST',
            body: JSON.stringify(payload)
        })
    ).json();

    if (response.error) {
        throw response;
    }

    return response;
};
