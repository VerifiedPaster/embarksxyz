import { trackInteraction } from '../../../tracking';
import { getContext } from '../../../context';
import { Form } from '../../../types';

export const redirectAction = async (url: string, form: Form): Promise<void> => {
    await trackInteraction(form);

    getContext().navigation.redirect(url);
};
