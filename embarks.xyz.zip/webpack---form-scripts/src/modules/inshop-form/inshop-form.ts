import { InshopFormData } from './types';
import { getFormIDSelector } from '../../elements';

export function createElement(form: InshopFormData): HTMLElement {
    const formElement = document.createElement('div');
    formElement.setAttribute('id', getFormIDSelector(form.id));

    return formElement;
}
